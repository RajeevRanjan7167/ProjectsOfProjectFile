﻿namespace OriginalAndConsulTemplateDemo
{
    public class DemoAppSettings
    {
        public string Key1 { get; set; }
        public string Key2 { get; set; }
    }
}
