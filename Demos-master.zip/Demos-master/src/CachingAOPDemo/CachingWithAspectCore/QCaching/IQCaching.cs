﻿namespace CachingWithAspectCore.QCaching
{
    public interface IQCaching
    {
    }
}
