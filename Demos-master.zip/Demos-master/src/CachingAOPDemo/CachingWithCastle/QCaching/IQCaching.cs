﻿namespace CachingWithCastle.QCaching
{
    public interface IQCaching
    {
    }
}
