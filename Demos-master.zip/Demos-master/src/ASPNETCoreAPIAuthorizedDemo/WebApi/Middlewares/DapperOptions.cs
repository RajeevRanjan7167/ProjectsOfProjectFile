﻿namespace WebApi.Middlewares
{
    public class DapperOptions
    {
        public string ConnectionString { get; set; }
    }
}
