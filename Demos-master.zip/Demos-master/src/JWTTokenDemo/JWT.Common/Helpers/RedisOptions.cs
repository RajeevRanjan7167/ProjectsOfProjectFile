﻿namespace JWT.Common.Helpers
{
    public class RedisOptions
    {
        public string MasterServer { get; set; }
        public string SlaveServer { get; set; }
    }
}
