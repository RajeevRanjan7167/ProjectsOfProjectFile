Data packages contain data files like custom dictionaries,
non-overridable configuration files, custom initialized data files, etc.

Service Fabric will recycle all EXEs and DLLHOSTs specified in the host and support packages when any of the data packages
specified inside service manifest are upgraded.