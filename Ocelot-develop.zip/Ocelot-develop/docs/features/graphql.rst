GraphQL
=======

OK you got me Ocelot doesn't directly support GraphQL but so many people have asked about it I wanted to show how easy it is to integrate the `graphql-dotnet <https://github.com/graphql-dotnet/graphql-dotnet>`_ library. 


Please see the sample project `OcelotGraphQL <https://github.com/ThreeMammals/Ocelot/tree/master/samples/OcelotGraphQL>`_. Using a combination of the graphql-dotnet project and Ocelot's DelegatingHandler features this is pretty easy to do. 
However I do not intend to integrate more closely with GraphQL at the moment. Check out the samples readme and that should give you enough instruction on how to do this!

Good luck and have fun :>


