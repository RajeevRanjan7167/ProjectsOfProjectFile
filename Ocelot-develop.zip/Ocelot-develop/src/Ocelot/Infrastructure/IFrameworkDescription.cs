namespace Ocelot.Infrastructure
{
    public interface IFrameworkDescription
    {
        string Get();
    }
}
