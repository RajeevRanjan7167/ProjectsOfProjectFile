﻿namespace Ocelot.Requester
{
    public interface ITracingHandler
    {
    }
}
