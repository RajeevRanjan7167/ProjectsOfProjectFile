namespace Ocelot.Requester
{
    using System.Net.Http;

    public class NoQosDelegatingHandler : DelegatingHandler
    {
    }
}
