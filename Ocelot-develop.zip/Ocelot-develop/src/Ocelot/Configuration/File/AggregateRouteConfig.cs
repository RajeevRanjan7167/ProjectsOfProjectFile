﻿namespace Ocelot.Configuration.File
{
    public class AggregateRouteConfig
    {
        public string RouteKey { get; set; }
        public string Parameter { get; set; }
        public string JsonPath { get; set; }
    }
}
