namespace Ocelot.Configuration.File
{
    public class FileHostAndPort
    {
        public string Host { get; set; }
        public int Port { get; set; }
    }
}
